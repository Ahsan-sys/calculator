package com.example.calculator;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import org.mariuszgromada.math.mxparser.*;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button One,Two,Three,Four,Five,Six,Seven,Eight,Nine,Zero,Mul,Div,Clear;

    Button ADD,SUB,Point,Sign,Brackets,Equal,power;
    EditText display;
    Boolean checkbracket =false;
    TextView output;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       One =findViewById(R.id.one);
        Two =findViewById(R.id.two);
        Three =findViewById(R.id.three);
        Four =findViewById(R.id.four);
        Five =findViewById(R.id.five);
        Six =findViewById(R.id.six);
        Seven =findViewById(R.id.seven);
        Eight =findViewById(R.id.eight);
        Nine =findViewById(R.id.nine);
        Clear =findViewById(R.id.C);
        Mul =findViewById(R.id.mul);
        Div =findViewById(R.id.div);
        ADD = findViewById(R.id.add);
        SUB = findViewById(R.id.sub);
        Point = findViewById(R.id.point);
        Sign= findViewById(R.id.sign);
        Zero= findViewById(R.id.zero);
        Equal=findViewById(R.id.equal);
        power = findViewById(R.id.power);
Brackets = findViewById(R.id.brackets);
   display = findViewById(R.id.display);
   output= findViewById(R.id.output);
   display.setShowSoftInputOnFocus(false);
        One.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {

    }
});
        Two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               update("2");
            }
        });
        Three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                update("3");
            }
        });
        Four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                  update("4");
            }
        });

        Five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                   update("5");
            }
        });
        Six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
   update("6");
            }
        });
        Seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                update("7");

            }
        });
        Eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                update("8");

            }
        });
        Nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                  update("9");
            }
        });
        Mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                update("*");


            }
        });
        Div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                update("/");
            }
        });
        ADD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
        update("+");
            }
        });
        SUB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              update("-");
            }
        });
        Point.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               update(".");
            }
        });
        Sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
       Equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String d = display.getText().toString();

               Expression exp = new Expression(d);
               String result = String.valueOf(exp.calculate());
               output.setText(result);

            }
        });


        Brackets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            if(checkbracket) {
                 update(")");
                checkbracket = false;
             }else{

                 update("(");
                checkbracket = true;

            }
            }
        });


        Zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                update("0");

            }
        });
        power.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                update("^");

            }
        });
        Clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 display.setText("");
                 output.setText("");
            }
        });
        One.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
update("1");
            }
        });



    }
    private void update(String e){
        String old = display.getText().toString();
        int cursor = display.getSelectionStart();
        String left = old.substring(0,cursor);
        String right = old.substring(cursor);
        display.setText(String.format("%s%s%s",left,e,right));
        display.setSelection(cursor+1);
    }





}
